


exports.Z7stara = (req, res) => {
    res.send('Welcome to /z7stara');
  };
  
  exports.Z7nowa = (req, res) => {
    res.send('Welcome to /z7nowa');
  };