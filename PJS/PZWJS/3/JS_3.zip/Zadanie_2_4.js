"use strict";
exports.__esModule = true;
var Zadanie_2_1_2_1 = require("./Zadanie_2_1_2");
var Zadanie_2_3_1 = require("./Zadanie_2_3");
var auto = new Zadanie_2_1_2_1.car("BMW", 2003, "e60");
var tir = new Zadanie_2_3_1.Truck("Audi", 2011, "A6");
console.log(auto.Result());
console.log(tir.Result());
