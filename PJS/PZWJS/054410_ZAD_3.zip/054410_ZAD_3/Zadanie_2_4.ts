import { car } from "./Zadanie_2_1_2";
import { Truck } from "./Zadanie_2_3";

let auto = new car("BMW", 2003, "e60");
let tir = new Truck("Audi",2011, "A6")

console.log(auto.Result())
console.log(tir.Result())