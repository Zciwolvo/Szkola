//plik konfiguracyjny serwera
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cookiePareser = require('cookie-parser');
const flash = require('connect-flash');
const session = require('express-session');
const routes = require('./routes/index');

const app = express();

//silnik
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

//zasoby
app.use(express.static(path.join(__dirname, 'public')));

//dodanie modułów
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//ciasteczka
app.use(cookiePareser());
app.use(session({
    secret: 'tajne haslo',
    resave: false,
    saveUninitialized: true,
    cookie: {}
}));

//flash
app.use(flash());

//trasy
app.use('/', routes);

//export
module.exports = app;