//Za pomocą modułu url:
// Dokonaj podziału 3 adresów URL wybranych z sieci i rozpoznaj:
// ich typ (pl, edu, com),
// parametry query,
// Ścieżkę oraz hash.

var url = require('url');

var url1 = 'https://www.google.com/search?client=firefox-b-d&q=js+tutorial';
var url2 = 'https://www.bing.com/search?q=javascript+tutorial&form=QBLH&sp=-1&pq=javascript+t&sc=6-12&qs=n&sk=&cvid=F08E139493D54D17B94D886B492F5C7F';
var url3 = 'https://duckduckgo.com/?q=javascript+tutorial&t=h_&ia=web';

//url1
//typ
var type = url.parse(url1).hostname;
type = type.split(".").pop();
console.log("Type: " + type);

//query
var query1 = url.parse(url1).query;
console.log("Query: " + query1);

//ścieżka
var path1 = url.parse(url1).path;
console.log("Path: " + path1);

//hash
var hash1 = url.parse(url1).hash;
console.log("Hash: " + hash1);

//url2
//typ
var type2 = url.parse(url2).hostname;
type2 = type2.split(".").pop();
console.log("Type: " + type2);

//query
var query2 = url.parse(url2).query;
console.log("Query: " + query2);

//ścieżka
var path2 = url.parse(url2).path;
console.log("Path: " + path2);

//hash
var hash2 = url.parse(url2).hash;
console.log("Hash: " + hash2);

//url3
//typ
var type3 = url.parse(url3).hostname;
type3 = type3.split(".").pop();
console.log("Type: " + type3);

//query
var query3 = url.parse(url3).query;
console.log("Query: " + query1);

//ścieżka
var path3 = url.parse(url3).path;
console.log("Path: " + path3);

//hash
var hash3 = url.parse(url3).hash;
console.log("Hash: " + hash3);